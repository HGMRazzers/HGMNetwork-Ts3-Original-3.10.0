insert into :table: (server_id, name, type, org_group_id) values (:server_id:, :name*:, :type:, :org_group_id*:) [[[,(:server_id:, :name*:, :type:, :org_group_id*:)]]];
